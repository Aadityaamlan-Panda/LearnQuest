from flask import Flask, request, jsonify, render_template
import numpy as np
import pytesseract
from PIL import Image
import io
from PIL import UnidentifiedImageError, ImageEnhance, ImageFilter
import wikipediaapi
from googleapiclient.discovery import build
import cohere
import requests
import os
import cv2

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

app = Flask(__name__, static_folder="static", template_folder="templates")

@app.route("/")
def index():
    return render_template("index.html")

# Initialize APIs
wiki = wikipediaapi.Wikipedia(
    language="en",
    user_agent="EducationalFlaskApp/1.0 (https://github.com/Aadityaamlan-Panda/LearnQuest; example@gmail.com)"
)

YOUTUBE_API_KEY = "" # Replace with your YouTube API key
youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
cohere_client = cohere.Client("")  # Replace with your Cohere API key

DICTIONARY_API_KEY = ""  # Replace with your Merriam-Webster Dictionary API key

# Helper Function: Improved Wikipedia Search
import wikipedia

def expanded_wikipedia_search(search_queries):
    """
    Perform an expanded search on Wikipedia using the provided queries.
    """
    results = {}
    for query in search_queries:
        try:
            # Try the initial query
            wiki_summary = wikipedia.summary(query, sentences=3)
            results[query] = wiki_summary
        except wikipedia.DisambiguationError as e:
            # Handle disambiguation by taking the first valid result
            for option in e.options:
                try:
                    wiki_summary = wikipedia.summary(option, sentences=3)
                    results[query] = wiki_summary
                    break
                except Exception:
                    continue
        except wikipedia.PageError:
            results[query] = "No relevant Wikipedia content found for this query."
        except Exception as e:
            results[query] = f"An error occurred: {str(e)}"
    return results

# Updated /process-text Route with Direct Embedding
@app.route("/process-text", methods=["POST"])
def process_text():
    """Analyze the highlighted text and provide related resources."""
    data = request.json
    paragraph = data.get("paragraph", "")
    highlighted = data.get("highlighted", "")

    if not paragraph or not highlighted:
        return jsonify({"error": "Invalid input. Provide both paragraph and highlighted text."}), 400

    # Extract most important term(s) from the highlighted text using Cohere
    prompt_term = f"""
    Highlighted text: {highlighted}
    Extract the most important term or terms from this text (e.g., keywords or phrases):
    """
    cohere_response_term = cohere_client.generate(
        model="command-xlarge-nightly",
        prompt=prompt_term,
        max_tokens=10,
        temperature=0.7
    )
    extracted_term = cohere_response_term.generations[0].text.strip()

    # Fetch the definition of the extracted term using the dictionary API
    definition = "No definition found."
    if extracted_term:
        try:
            dict_url = f"https://www.dictionaryapi.com/api/v3/references/collegiate/json/{extracted_term}?key={DICTIONARY_API_KEY}"
            response = requests.get(dict_url)
            if response.status_code == 200:
                definition_data = response.json()
                if definition_data and isinstance(definition_data, list):
                    for entry in definition_data:
                        if isinstance(entry, dict) and 'shortdef' in entry:
                            definition = " / ".join(entry['shortdef'])
                            break
        except Exception as e:
            print(f"Error fetching definition: {str(e)}")

    # Relate the highlighted text to the paragraph
    paragraph = extract_surrounding_context(paragraph, highlighted)

    prompt_relation = f"""
    Highlighted text: {highlighted}
    Paragraph: {paragraph}
    Provide a brief summary relating the highlighted text to the context of the paragraph:
    """
    cohere_response_relation = cohere_client.generate(
        model="command-xlarge-nightly",
        prompt=prompt_relation,
        max_tokens=100,
        temperature=0.7
    )
    relation = cohere_response_relation.generations[0].text.strip()

    # Generate a search query based on the highlighted text and paragraph
    prompt_query = f"""
    Based on the context:
    Highlighted text: {highlighted}
    Paragraph: {paragraph}
    Suggest a most single word or 2-3 words search query for finding more information online (Wikipedia, Google, YouTube, etc.):
    """
    cohere_response_query = cohere_client.generate(
        model="command-xlarge-nightly",
        prompt=prompt_query,
        max_tokens=20,
        temperature=0.7
    )
    search_query = cohere_response_query.generations[0].text.strip()

    # Prepare both queries for search
    search_queries = [extracted_term, search_query]

    # Expanded Wikipedia Search
    wiki_results = expanded_wikipedia_search(search_queries)

    # Fetch related YouTube videos for both queries
    videos = []

    for query in search_queries:
        try:
            # Call YouTube API to search videos
            search_response = youtube.search().list(
                q=query.strip(),
                part="snippet",
                maxResults=2,
                type="video"
            ).execute()

            for item in search_response.get("items", []):
                video_id = item.get("id", {}).get("videoId", "")
                if not video_id:
                    continue  # Skip if no video ID is present

                # Validate video availability
                video_details = youtube.videos().list(
                    part="status",
                    id=video_id
                ).execute()

                # Check video status
                if video_details.get("items"):
                    video_status = video_details["items"][0].get("status", {})
                    if video_status.get("privacyStatus") == "public" and video_status.get("embeddable"):
  # Only include public videos
                        snippet = item.get("snippet", {})
                        title = snippet.get("title", "No Title")
                        thumbnail = snippet.get("thumbnails", {}).get("default", {}).get("url", "")
                        videos.append({
                            "title": title,
                            "thumbnail": thumbnail,
                            "embed": f"https://www.youtube.com/embed/{video_id}",
                            "videoId": video_id
                        })

        except Exception as e:
            print(f"Error fetching YouTube videos for query '{query}': {str(e)}")

    # Remove duplicate videos
    unique_videos = {video["embed"]: video for video in videos}.values()
    videos = list(unique_videos)
    print(videos)
    return jsonify({
        "extracted_term": extracted_term,
        "definition": definition,
        "relation": relation,
        "search_query": search_query,
        "wikipedia_url": f"https://en.wikipedia.org/wiki/Special:Search?search={search_query}",
        "google_url": f"https://cse.google.com/cse?cx=your_cx_id&q={search_query}",
        "videos": videos,
    })

def extract_surrounding_context(paragraph, highlighted_text, window_size=3):
    """Extracts the surrounding context (previous and next lines or sentences) of the highlighted text."""
    # Split the paragraph into sentences
    sentences = paragraph.split('.')
    
    # Find the sentence containing the highlighted text
    for i, sentence in enumerate(sentences):
        if highlighted_text in sentence:
            # Extract a window of sentences around the highlighted text
            start = max(i - window_size, 0)
            end = min(i + window_size + 1, len(sentences))
            return ' '.join(sentences[start:end]).strip()
    
    return ""  # In case no highlighted text is found


@app.route("/convert-image", methods=["POST"])
def convert_image():
    """Convert an uploaded image to text using OCR with preprocessing and robust logging."""
    # Check if an image file is provided
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided."}), 400

    image_file = request.files['image']
    print("Received file:", image_file.filename)

    # Save the uploaded image for debugging purposes
    debug_file_path = "debug_uploaded_image.jpg"
    try:
        image_file.save(debug_file_path)
        print(f"Saved uploaded image to {debug_file_path} for debugging.")
    except Exception as e:
        print("Error saving uploaded image:", e)
        return jsonify({"error": "Failed to save uploaded image."}), 500

    # Preprocess the image
    image = preprocess_image(debug_file_path)
    if image is None:
        return jsonify({"error": "Preprocessing failed."}), 500

    # Perform OCR on the preprocessed image
    try:
        print("Currently converting to text...")
        text = pytesseract.image_to_string(image, lang="eng", config="--psm 6")
        print("Converted to text successfully.")
        print("OCR Output:", repr(text))

        # Check if the OCR output is empty
        if not text.strip():
            print("No text detected in the image.")
            text = "No text detected. Please provide a clearer image."
    except Exception as e:
        print("Error during OCR processing:", e)
        return jsonify({"error": "OCR processing failed."}), 500

    # Clean up the saved debug file
    try:
        os.remove(debug_file_path)
        print(f"Debug file {debug_file_path} removed successfully.")
    except Exception as e:
        print("Error removing debug file:", e)

    # Return the extracted text
    return jsonify({"text": text})

def preprocess_image(image_path):
    """Improved preprocessing for OCR."""
    try:
        # Load the image
        image = Image.open(image_path)
        print("Image successfully loaded.")

        # Rescale the image
        image = image.resize((image.width * 2, image.height * 2), Image.Resampling.LANCZOS)
        print("Image rescaled.")

        # Convert to grayscale
        image = image.convert("L")
        print("Converted to grayscale.")

        # Adaptive thresholding
        opencv_image = np.array(image)
        opencv_image = cv2.adaptiveThreshold(opencv_image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        print("Applied adaptive thresholding.")

        # Save intermediate image
        intermediate_path = "intermediate_preprocessed_image.jpg"
        cv2.imwrite(intermediate_path, opencv_image)
        print(f"Intermediate preprocessed image saved at {intermediate_path}.")

        # Convert back to PIL format
        image = Image.fromarray(opencv_image)

        # Save final preprocessed image
        preprocessed_path = "preprocessed_image.jpg"
        image.save(preprocessed_path)
        print(f"Final preprocessed image saved at {preprocessed_path}.")

        return image

    except Exception as e:
        print("Error during preprocessing:", e)
        return None



if __name__ == "__main__":
    app.run(debug=True)
