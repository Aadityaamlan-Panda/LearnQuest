document.addEventListener("DOMContentLoaded", () => {
    const analyzeBtn = document.getElementById("analyze-btn");
    const paragraphTextarea = document.getElementById("paragraph");
    const floatingResults = document.getElementById("floating-results");
    const youtubeVideosDiv = document.getElementById("youtube-videos");
    const wikipediaIframe = document.getElementById("wikipedia-iframe");
    const googleSearchDiv = document.getElementById("google-search-results");
    const convertBtn = document.getElementById("convert-btn");
    const imageUpload = document.getElementById("image-upload");
    const ocrResultsDiv = document.getElementById("ocr-results");

    const definitionText = document.getElementById("definition-text");
    const aiAnalysisText = document.getElementById("ai-analysis-text");

    let highlightedText = "";

    // Ensure the panel is hidden on load
    floatingResults.classList.remove("visible");
    floatingResults.style.visibility = "hidden";
    floatingResults.style.opacity = "0";

    // Detect text selection in the textarea
    paragraphTextarea.addEventListener("mouseup", () => {
        const textarea = paragraphTextarea;
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;

        highlightedText = start !== end ? textarea.value.substring(start, end).trim() : "";
        analyzeBtn.style.display = highlightedText ? "block" : "none";
    });

    // Analyze highlighted text
    analyzeBtn.addEventListener("click", async () => {
        if (!highlightedText) {
            alert("Please highlight some text to analyze.");
            return;
        }

        console.log("Highlighted Text:", highlightedText);

        const paragraph = paragraphTextarea.value;
        try {
            const response = await fetch("/process-text", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ paragraph, highlighted: highlightedText }),
            });

            const data = await response.json();
            console.log("API Response:", data);

            if (response.ok) {
                floatingResults.classList.add("visible"); // Make panel visible
                floatingResults.style.visibility = "visible"; // Ensure visible
                floatingResults.style.opacity = "1"; // Ensure fully opaque

                // Populate definition and AI analysis text
                definitionText.textContent = data.definition || "No definition found.";
                aiAnalysisText.textContent = data.relation || "No AI analysis available.";

                // Populate Wikipedia, YouTube, and Google Search results
                wikipediaIframe.src = data.wikipedia_url || "";
                displayYouTubeVideos(data.videos);
                displayGoogleSearchResults(data.search_query);
            } else {
                console.error("Error from API:", data);
                alert("An error occurred while analyzing text.");
            }
        } catch (error) {
            console.error("Fetch Error:", error);
            alert("An error occurred. Please try again later.");
        }
    });

    function displayYouTubeVideos(videos) {
        youtubeVideosDiv.innerHTML = "";
        if (!videos || videos.length === 0) {
            youtubeVideosDiv.innerHTML = "<p>No videos found.</p>";
            return;
        }
        videos.forEach((video) => {
            const videoElement = document.createElement("div");
            videoElement.innerHTML = ` 
                <h5>${video.title}</h5>
                <a href="https://www.youtube.com/watch?v=${video.videoId}" target="_blank">
                    <img src="${video.thumbnail}" alt="${video.title}" />
                </a>
            `;
            youtubeVideosDiv.appendChild(videoElement);
        });
    }

    function displayGoogleSearchResults(query) {
        googleSearchDiv.innerHTML = "";
        const searchElement = document.createElement("div");
        searchElement.classList.add("gcse-search");
        searchElement.setAttribute("data-query", query);

        const script = document.createElement("script");
        script.async = true;
        script.src = `https://cse.google.com/cse.js?cx=your_cx_id`;

        document.body.appendChild(script);
        googleSearchDiv.appendChild(searchElement);
    }

    // Hide the floating results panel if clicked outside of it
    document.addEventListener("click", (event) => {
        // Check if the click is outside the floating panel and the button
        if (!floatingResults.contains(event.target) && !analyzeBtn.contains(event.target)) {
            floatingResults.classList.remove("visible");
            floatingResults.style.visibility = "hidden";
            floatingResults.style.opacity = "0";
        }
    });

    convertBtn.addEventListener("click", async () => {
        const imageFile = imageUpload.files[0];
        if (!imageFile) {
            alert("Please upload an image to convert.");
            return;
        }

        const formData = new FormData();
        formData.append("image", imageFile);

        try {
            const response = await fetch("/convert-image", {
                method: "POST",
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                // Display extracted text
                paragraphTextarea.value = data.text;
            } else {
                console.error("Error from API:", data);
                alert("An error occurred while converting the image.");
            }
        } catch (error) {
            console.error("Fetch Error:", error);
            alert("An error occurred. Please try again later.");
        }
    });
});
